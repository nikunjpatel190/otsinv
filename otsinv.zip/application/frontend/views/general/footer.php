
</div>

<script type="application/javascript" src='js/jquery-2.0.3.min.js'></script>

<script type="text/javascript">
	if("ontouchend" in document) document.write("<script src='js/jquery.mobile.custom.min.js'>"+"<"+"/script>");
</script>

<script src="js/bootstrap.min.js"></script>
<!--page specific plugin scripts-->
<!--ace scripts-->
<script src="js/ace-elements.min.js"></script>
<script src="js/ace.min.js"></script>

<!--inline scripts related to this page-->

<script type="text/javascript">
	function show_box(id) {
	 $('.widget-box.visible').removeClass('visible');
	 $('#'+id).addClass('visible');
	}
</script>
        
<script type="text/javascript" src="js/common.js" language="javascript"></script>
<script type='text/javascript' src='js/function.js'></script>

</body>
</html>
